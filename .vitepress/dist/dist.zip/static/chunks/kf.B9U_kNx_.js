const t="/static/kf.CUtmQVOE.png";export{t as _};
