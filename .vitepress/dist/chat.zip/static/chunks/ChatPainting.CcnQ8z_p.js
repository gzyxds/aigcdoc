const t="/doc/static/v.BlRzispc.png",s="/doc/static/ChatPainting.s-3nN3VT.png";export{t as _,s as a};
