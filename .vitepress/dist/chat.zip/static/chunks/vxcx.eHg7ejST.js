const t="/doc/static/vxcx.7r24jN3z.png";export{t as _};
