const t="/doc/static/kf.D_N5zBhJ.png";export{t as _};
