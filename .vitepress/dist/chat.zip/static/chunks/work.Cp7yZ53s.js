const o="/doc/static/work.DExDCKXl.png";export{o as _};
