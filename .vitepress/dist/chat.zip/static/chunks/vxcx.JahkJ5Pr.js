const c="/doc/static/vxcx.Cqod5cww.png";export{c as _};
