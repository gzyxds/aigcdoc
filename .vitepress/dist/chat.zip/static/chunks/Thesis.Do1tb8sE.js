const s="/doc/static/human.05iz4fU9.svg",t="/doc/static/work.BSTsQASR.svg",o="/doc/static/Thesis.NNP4FDIm.png";export{s as _,t as a,o as b};
