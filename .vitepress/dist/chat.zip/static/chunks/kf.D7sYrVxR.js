const t="/doc/static/kf.CxtbZMJO.svg";export{t as _};
