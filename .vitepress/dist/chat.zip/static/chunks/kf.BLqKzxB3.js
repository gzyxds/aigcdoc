const s="/doc/static/kf.BHUKL5f_.svg";export{s as _};
