const o="/doc/static/kf.6jo_f6O2.png";export{o as _};
