const s="/doc/static/vxcx.BEIWVnvj.png",t="/doc/static/Thesis.NNP4FDIm.png";export{s as _,t as a};
