const t="/doc/static/kf.IzffFk7a.png";export{t as _};
