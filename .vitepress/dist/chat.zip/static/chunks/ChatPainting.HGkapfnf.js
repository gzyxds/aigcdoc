const t="/doc/static/ChatPainting.o19ac3BJ.svg";export{t as _};
