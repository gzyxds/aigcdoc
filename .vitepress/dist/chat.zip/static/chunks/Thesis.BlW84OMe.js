const s="/doc/static/vxcx.7r24jN3z.png",t="/doc/static/Thesis.NNP4FDIm.png";export{s as _,t as a};
